chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // We checken alleen als de pagina helemaal klaar is met laden
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes('nike.com')) {
        
        console.log("Nike gedetecteerd, checken voor cashback...");

        fetch('https://mijn-stripe-app.onrender.com/api/check-cashback', {
            method: 'GET',
            mode: 'cors' // Dit helpt bij Edge beveiliging
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'found') {
                chrome.notifications.create('cashback-alert', {
                    type: 'basic',
                    iconUrl: 'icon.png',
                    title: 'Cashback Alert!',
                    message: `Bespaar €${data.amount} bij ${data.shop}! Klik om te activeren.`,
                    priority: 2
                });
            }
        })
        .catch(err => console.error("Oeps, er ging iets mis:", err));
    }
});

chrome.notifications.onClicked.addListener(() => {
    chrome.tabs.create({ url: 'https://mijn-stripe-app.onrender.com/dashboard?activated=true' });
});