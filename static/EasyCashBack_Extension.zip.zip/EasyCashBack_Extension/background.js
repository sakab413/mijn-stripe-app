chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes('nike.com')) {
        fetch('https://mijn-stripe-app.onrender.com/api/check-cashback')
            .then(res => res.json())
            .then(data => {
                if (data.status === 'found') {
                    chrome.notifications.create({
                        type: 'basic',
                        iconUrl: 'icon.png',
                        title: 'Cashback Alert!',
                        message: `Bij ${data.shop} krijg je nu €${data.amount} terug! Open je dashboard om te claimen.`,
                        priority: 2
                    });
                }
            })
            .catch(err => console.log("Fout:", err));
    }
});